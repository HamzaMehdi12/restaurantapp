---
title: Bounding box
categories:
  - Graphics
tags:
  - text
  - shape
  - resize
  - dimensions
---
