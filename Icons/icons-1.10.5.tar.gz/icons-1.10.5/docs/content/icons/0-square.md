---
title: 0 square
categories:
  - Shapes
tags:
  - number
  - numeral
---
