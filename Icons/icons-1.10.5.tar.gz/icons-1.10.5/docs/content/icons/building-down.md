---
title: Building down
categories:
  - Buildings
tags:
  - company
  - enterprise
  - organization
  - office
  - business
---
